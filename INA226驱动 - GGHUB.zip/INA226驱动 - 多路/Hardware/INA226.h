#ifndef __INA226_H
#define __INA226_H

#include "stm32f10x.h"
#include "MyI2C.h"  // ����ײ�I2C����

//0x40
void INA226_WriteReg(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg(uint8_t RegAddress);
void INA226_Init(void);
uint32_t INA226_GetShuntVoltage(void);
uint32_t INA226_GetBusVoltage(void);
uint32_t INA226_GetCurrent(void);
uint32_t INA226_GetPower(void);



//0x41
void INA226_WriteReg2(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg2(uint8_t RegAddress);
void INA226_Init2(void);
uint32_t INA226_GetShuntVoltage2(void);
uint32_t INA226_GetBusVoltage2(void);
uint32_t INA226_GetCurrent2(void);
uint32_t INA226_GetPower2(void);


//0x42
void INA226_WriteReg3(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg3(uint8_t RegAddress);
void INA226_Init3(void);
uint32_t INA226_GetShuntVoltage3(void);
uint32_t INA226_GetBusVoltage3(void);
uint32_t INA226_GetCurrent3(void);
uint32_t INA226_GetPower3(void);

//0x43
void INA226_WriteReg4(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg4(uint8_t RegAddress);
void INA226_Init4(void);
uint32_t INA226_GetShuntVoltage4(void);
uint32_t INA226_GetBusVoltage4(void);
uint32_t INA226_GetCurrent4(void);
uint32_t INA226_GetPower4(void);

//0x44
void INA226_WriteReg5(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg5(uint8_t RegAddress);
void INA226_Init5(void);
uint32_t INA226_GetShuntVoltage5(void);
uint32_t INA226_GetBusVoltage5(void);
uint32_t INA226_GetCurrent5(void);
uint32_t INA226_GetPower5(void);


//0x45
void INA226_WriteReg6(uint8_t Register, uint8_t Data_H, uint8_t Data_L);
uint32_t INA226_ReadReg6(uint8_t RegAddress);
void INA226_Init6(void);
uint32_t INA226_GetShuntVoltage6(void);
uint32_t INA226_GetBusVoltage6(void);
uint32_t INA226_GetCurrent6(void);
uint32_t INA226_GetPower6(void);

#endif