#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include "MyI2C.h"
#include "INA226.h"
#include "lcd.h"
#include "lcd_init.h"
#include "pic.h"

#define shift1 25
#define shift2 115

uint32_t ShuntVoltage=0, BusVoltage=0, Current=0, Power=0;			//定义用于存放各个数据的变量
uint32_t ShuntVoltage2=0, BusVoltage2=0, Current2=0, Power2=0;
uint32_t ShuntVoltage3=0, BusVoltage3=0, Current3=0, Power3=0;
uint32_t ShuntVoltage4=0, BusVoltage4=0, Current4=0, Power4=0;
uint32_t ShuntVoltage5=0, BusVoltage5=0, Current5=0, Power5=0;
uint32_t ShuntVoltage6=0, BusVoltage6=0, Current6=0, Power6=0;
int main(void)
{
	
	/*模块初始化*/
	MyI2C_Init();
	LCD_Init();//屏幕初始化
    LCD_Fill(0,0,LCD_W,LCD_H,BLACK);//清全屏为黑色
	
	
	
	LCD_ShowString(68, 16*4, (uint8_t *)"GG Hub", WHITE, BLACK, 32, 0);
	Delay_ms(1000);
	LCD_ShowString(68, 16*6, (uint8_t *)"GGD", WHITE, BLACK, 32, 0);
	Delay_ms(800);
	LCD_ShowString(68, 16*6, (uint8_t *)"Geek", WHITE, BLACK, 32, 0);
	Delay_ms(300);
	LCD_ShowString(68, 16*8, (uint8_t *)"Go", WHITE, BLACK, 32, 0);
	Delay_ms(300);
	LCD_ShowString(68, 16*10, (uint8_t *)"Device", WHITE, BLACK, 32, 0);
	Delay_ms(200);
	
	LCD_ShowString(68, 16*6, (uint8_t *)"Geek", WHITE, RED, 32, 0);
	//Delay_ms(300);
	LCD_ShowString(68, 16*8, (uint8_t *)"Go", BLACK, GREEN, 32, 0);
	//Delay_ms(300);
	LCD_ShowString(68, 16*10, (uint8_t *)"Device", BLACK, LIGHTBLUE, 32, 0);
	
	
	Delay_ms(1200);
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	LCD_ShowPicture(55, 100, 135, 46, gImage_pic);
	Delay_ms(1000);
	//上面这段都是延时logo的，可以改成自己的
	
	LCD_Fill(0,0,LCD_W,LCD_H,BLACK);//清全屏为黑色

		
	//OLED_Init();	
	INA226_Init();
	INA226_Init2();
	INA226_Init3();
	INA226_Init4();
	INA226_Init5();
	INA226_Init6();
	
	Delay_ms(100);//初始化延时
	while (1)
	{
		ShuntVoltage = INA226_GetShuntVoltage();
		//Delay_ms(100);
		BusVoltage = INA226_GetBusVoltage();
		//Delay_ms(100);
		Current = INA226_GetCurrent();
		//Delay_ms(100);
		Power = INA226_GetPower();
		
		ShuntVoltage2 = INA226_GetShuntVoltage2();
		//Delay_ms(100);
		BusVoltage2 = INA226_GetBusVoltage2();
		//Delay_ms(100);
		Current2 = INA226_GetCurrent2();
		//Delay_ms(100);
		Power2 = INA226_GetPower2();
		
		ShuntVoltage3 = INA226_GetShuntVoltage3();
		//Delay_ms(100);
		BusVoltage3 = INA226_GetBusVoltage3();
		//Delay_ms(100);
		Current3 = INA226_GetCurrent3();
		//Delay_ms(100);
		Power3 = INA226_GetPower3();
		
		ShuntVoltage4 = INA226_GetShuntVoltage4();
		//Delay_ms(100);
		BusVoltage4 = INA226_GetBusVoltage4();
		//Delay_ms(100);
		Current4 = INA226_GetCurrent4();
		//Delay_ms(100);
		Power4 = INA226_GetPower4();
		
		ShuntVoltage5 = INA226_GetShuntVoltage5();
		//Delay_ms(100);
		BusVoltage5 = INA226_GetBusVoltage5();
		//Delay_ms(100);
		Current5 = INA226_GetCurrent5();
		//Delay_ms(100);
		Power5 = INA226_GetPower5();
		
		ShuntVoltage6 = INA226_GetShuntVoltage6();
		//Delay_ms(100);
		BusVoltage6 = INA226_GetBusVoltage6();
		//Delay_ms(100);
		Current6 = INA226_GetCurrent6();
		//Delay_ms(100);
		Power6 = INA226_GetPower6();
		
		
	
		//0x40
		LCD_ShowString(2+shift1,16,(uint8_t *)"  Port 1 ",BLACK,LIGHTGREEN,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1,16*2,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1, 16*2, BusVoltage, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*2,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1,16*3,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1, 16*3,Current , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*3,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1,16*4,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1, 16*4,Power , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*4,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		
		//0x41
		LCD_ShowString(2+shift1+shift2,16,(uint8_t *)"  Port 2 ",WHITE,LBBLUE,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1+shift2,16*2,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*2, BusVoltage2, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*2,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1+shift2,16*3,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*3,Current2 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*3,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1+shift2,16*4,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*4,Power2 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*4,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		
		
		//0x42
		LCD_ShowString(2+shift1,16*6,(uint8_t *)"  Port 3 ",WHITE,BRRED,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1,16*7,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1, 16*7, BusVoltage3, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*7,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1,16*8,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1, 16*8,Current3 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*8,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1,16*9,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1, 16*9,Power3 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*9,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		
		//0x43
		LCD_ShowString(2+shift1+shift2,16*6,(uint8_t *)"  Port 4 ",BLACK,LGRAY,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1+shift2,16*7,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*7, BusVoltage4, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*7,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1+shift2,16*8,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*8,Current4 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*8,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1+shift2,16*9,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*9,Power4 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*9,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		
		//0x44
		LCD_ShowString(2+shift1,16*11,(uint8_t *)"  Port 5 ",BLACK,YELLOW,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1,16*12,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1, 16*12, BusVoltage5, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*12,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1,16*13,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1, 16*13,Current5 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*13,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1,16*14,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1, 16*14,Power5 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1,16*14,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		
		//0x45
		LCD_ShowString(2+shift1+shift2,16*11,(uint8_t *)"  Port 6 ",BLACK,LGRAYBLUE,16, 0);
		
		//OLED_ShowString(2,1,"BusV:");OLED_ShowSignedNum(2, 9, BusVoltage, 6);//单位mV
		LCD_ShowString(0+shift1+shift2,16*12,(uint8_t *)"V:",WHITE,RED,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*12, BusVoltage6, 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*12,(uint8_t *)"mV",WHITE,RED,16, 0);
		
		//OLED_ShowString(3,1,"Current:");OLED_ShowSignedNum(3, 9, Current, 6);//单位mA
		LCD_ShowString(0+shift1+shift2,16*13,(uint8_t *)"I:",WHITE,BLUE,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*13,Current6 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*13,(uint8_t *)"mA",WHITE,BLUE,16, 0);
		
		//OLED_ShowString(4,1,"Power:");OLED_ShowSignedNum(4, 9, Power, 6);//单位mW
		LCD_ShowString(0+shift1+shift2,16*14,(uint8_t *)"P:",BLACK,GREEN,16, 0);
		LCD_ShowIntNum(22+shift1+shift2, 16*14,Power6 , 4, WHITE, BLACK, 16);
		LCD_ShowString(60+shift1+shift2,16*14,(uint8_t *)"mW",BLACK,GREEN,16, 0);
		
		LCD_ShowString(20,16*16,(uint8_t *)"6 CHANNEL HUB BY GGD 2025",WHITE,BLACK,16, 0);
		
		Delay_ms(100);
	}
}

